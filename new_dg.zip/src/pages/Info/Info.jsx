import React from 'react'
import NewBar from '../../components/latestNews/NewBar'
import VerticalCard from '../../components/vericalCard/VerticalCard'

function Info({data, title, title_p, img, p,p2,p3,p4,p5}) {
return (
<>
    <div className="row">
        <div className="col-3 d-none d-lg-block border-end">
            <h4><span className="main-icon">*</span> Latest news</h4>
            <NewBar />
            <NewBar />
            <NewBar />
            <NewBar />
            <NewBar />
            <NewBar />
            <NewBar />
            <NewBar />
        </div>
        <div className="col-lg-9 col-12">
            <p className='data text-secondary'>{data}</p>
            <h3 className='title'>{title}</h3>
            <p className='title_p fw-bold fs-5'>{title_p}</p>
            <div>
                <img src={img} className="mt-3 mb-4 w-100" alt="Person" />                
            </div>
            <p>{p}</p>
            <p>{p2}</p>
            <p>{p3}</p>
            <p>{p4}</p>
            <p>{p5}</p>
        </div>
    </div>
    <div className="related-news">
        <h4><span className="main-icon">*</span> Editor's Choice</h4>
        <div className="row mt-5">
            <div className="col-xl-3 col-md-6 col-12 mb-5">
                <VerticalCard width='18rem'
                    img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg"
                    data="14:39 / 03.02.2022"
                    title="Tashkent among TOP-3 most popular destinations for tourists from Russia" />
            </div>

            <div className="col-xl-3 col-md-6 col-12 mb-5">
                <VerticalCard width='18rem'
                    img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg"
                    data="14:39 / 03.02.2022"
                    title="Tashkent among TOP-3 most popular destinations for tourists from Russia" />
            </div>

            <div className="col-xl-3 col-12 col-12 mb-5">
                <VerticalCard width='18rem'
                    img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg"
                    data="14:39 / 03.02.2022"
                    title="Tashkent among TOP-3 most popular destinations for tourists from Russia" />
            </div>

            <div className="col-xl-3 col-12 col-12 mb-5">
                <VerticalCard width='18rem'
                    img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg"
                    data="14:39 / 03.02.2022"
                    title="Tashkent among TOP-3 most popular destinations for tourists from Russia" />
            </div>
        </div>


        <div className="row mt-5">
            <h5 className='mb-3'> 
                News
            </h5>
            <div className="col-xl-3 col-md-6 col-12 mb-5">
                <VerticalCard width='18rem'
                    img="https://storage.kun.uz/source/thumbnails/_medium/9/IxNA2DNTF2KJMyXz2mjDb_5bDWHZ3si8_medium.jpg"
                    data="14:39 / 03.02.2022"
                    title="Energy Ministry takes legal action against LLC that used 2.3 billion soums worth of electricity illegally" />
            </div>

            <div className="col-xl-3 col-md-6 col-12 mb-5">
                <VerticalCard width='18rem'
                    img="https://storage.kun.uz/source/thumbnails/_medium/9/IxNA2DNTF2KJMyXz2mjDb_5bDWHZ3si8_medium.jpg"
                    data="14:39 / 03.02.2022"
                    title="Energy Ministry takes legal action against LLC that used 2.3 billion soums worth of electricity illegally" />
            </div>

            <div className="col-xl-3 col-12 col-12 mb-5">
                <VerticalCard width='18rem'
                    img="https://storage.kun.uz/source/thumbnails/_medium/9/IxNA2DNTF2KJMyXz2mjDb_5bDWHZ3si8_medium.jpg"
                    data="14:39 / 03.02.2022"
                    title="Energy Ministry takes legal action against LLC that used 2.3 billion soums worth of electricity illegally" />
            </div>

            <div className="col-xl-3 col-12 col-12 mb-5">
                <VerticalCard width='18rem'
                    img="https://storage.kun.uz/source/thumbnails/_medium/9/IxNA2DNTF2KJMyXz2mjDb_5bDWHZ3si8_medium.jpg"
                    data="14:39 / 03.02.2022"
                    title="Energy Ministry takes legal action against LLC that used 2.3 billion soums worth of electricity illegally" />
            </div>
        </div>
    </div>
</>
)
}

export default Info