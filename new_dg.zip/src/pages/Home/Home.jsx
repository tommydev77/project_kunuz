import React from 'react'
import "./Home.scss"
import Card from '../../components/ads/Card'
import NewBar from '../../components/latestNews/NewBar'
import MainNewsImg from "../../assets/images/main-news.jpg"
import MainNews from '../../components/mainNews/MainNews'
import VerticalCard from '../../components/vericalCard/VerticalCard'
import InfoImage from "../../assets/images/dok1.jpg"
import MainCardImg from "../../assets/images/main-card.jpg";
import OptimizeImg from "../../assets/images/optimize.webp";
import Vid from "https://streamable.com/y8s0fq";
function Home() {
	let data = [
        {
            id: 1,
            title: "News 1 News 1 News 1 News 1 News 1 News 1 News 1 News 1 News 1 News 1",
            data: '1:18',
			img: InfoImage,
        },


        {
            id: 2,
            title: "News 2 News 2 News 2 News 2 News 2 News 2 News 2 News 2 News 2 News 2",
            data: '01:50',
			img: MainNewsImg,
        },

        {
            id: 3,
            title: "News 3 News 3 News 3 News 3 News 3 News 3 News 3 News 3 News 3 News 3",
            data: '10:20',
			img: MainCardImg,
        },

		{
            id: 4,
            title: "News 4 News 4 News 4 News 4 News 4 News 4 News 4 News 4 News 4 News 4",
            data: '12:50',
			img: OptimizeImg,
        },
    ];
    return (
        <>
			<div className="container-top">
				<div className="row">
					<div className="col-lg-9 col-12">
						<Card img={InfoImage} link="/info" data="12:34/30.12.2022" p="Zarifboy Ibodullayev, professor of the Tashkent Medical Academy, in an interview with Kun.uz, commented on the Doc-1 Max tragedy, accused the Ministry of Health of being indifferent to the WHO warning about the death of 69 children in Gambia." text="Medical professor blamed Health Ministry for Doc-1 Max events" />

						<div className="flex-display mt-5">
							{data.map((value, key) => (
								<MainNews img={value.img} title={value.title} data={value.data} key={value.id} />
							))}
						</div>


						<div className="editors-choice mt-4">
							<h4><span className="main-icon">*</span> Editor's Choice</h4>
							<div className="row mt-5">
								<div className="col-xl-4 col-md-6 col-12 mb-5">
									<VerticalCard width='18rem' img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg" data="14:39 / 03.02.2022" title="Tashkent among TOP-3 most popular destinations for tourists from Russia"/>
								</div>

								<div className="col-xl-4 col-md-6 col-12 mb-5">
									<VerticalCard width='18rem' img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg" data="14:39 / 03.02.2022" title="Tashkent among TOP-3 most popular destinations for tourists from Russia"/>
								</div>

								<div className="col-xl-4 col-12 col-12 mb-5">
									<VerticalCard width='18rem' img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg" data="14:39 / 03.02.2022" title="Tashkent among TOP-3 most popular destinations for tourists from Russia"/>
								</div>
							</div>
						</div>
					</div>

					<div className="col-3 d-none d-lg-block">
						<h4><span className="main-icon">*</span> Latest news</h4>
						<NewBar />
						<NewBar />
						<NewBar />
						<NewBar />
						<NewBar />
						<NewBar />
						<NewBar />
						<NewBar />
					</div>
				</div>
			</div>

			<div className="container-bottom">
				<div className="actual-news mt-5">
					<h4><span className="main-icon">*</span> Actual news</h4>
					<div className="row mt-5">
						<div className="col-xl-6 mb-5">
							<VerticalCard width='30rem' img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg" data="14:39 / 03.02.2022" text="Responsible persons were tasked with ensuring the stability of the financial system, the reliability of the transport and logistics network and the social protection of the population." title="Tashkent among TOP-3 most popular destinations for tourists from Russia"/>
						</div>
						<div className="col-md-6">
							<div className="row">
								<div className="col-xl-6 mb-5">
									<VerticalCard width='100%' img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg" title="Tashkent among TOP-3 most popular."/>
								</div>
								<div className="col-xl-6 mb-5">
									<VerticalCard width='100%' img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg" title="Tashkent among TOP-3 most popular."/>
								</div>
							</div>

							<div className="row">
								<div className="col-xl-6 mb-5">
									<VerticalCard width='100%' img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg" title="Tashkent among TOP-3 most popular."/>
								</div>
								<div className="col-xl-6 mb-5">
									<VerticalCard width='100%' img="https://storage.kun.uz/source/thumbnails/_medium/8/SfUjPIBtiv-tD5guAhGrZ9DDTbnCXbrk_medium.jpg" title="Tashkent among TOP-3 most popular."/>
								</div>
							</div>
						</div>
					</div>
				</div>


				<div className="videos">
					<h4><span className="main-icon">*</span> Videos</h4>

					<div className="row mt-5">
						<div className="col-md-6">
							<video width="100%" height="500" controls >
								<source src={Vid} type="video/mp4"/>
							</video>
						</div>

						<div className="col-md-6">
							<video width="100%" height="500" controls >
								<source src={Vid} type="video/mp4"/>
							</video>
						</div>
					</div>
				</div>
			</div>
        </>
    )
}

export default Home
