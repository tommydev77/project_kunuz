import React from 'react'
import Card from '../../components/SMCard/Card'
import "./Business.scss"
import Img from "../../assets/images/main-card.jpg"
function Business() {
    let data = [
        {
            id: 1,
            title: "product",
            weight: 50
        },


        {
            id: 2,
            title: "product",
            weight: 50
        },

        {
            id: 3,
            title: "product",
            weight: 50
        },
    ] 

    return (
        <>
            <div className="row">
                <div className="col-md-9">
                    {data.map((value, key)=>(
                        <Card img={Img} text={value.title} p={value.weight} key={key} data={value.id}/>
                    ))}
                </div>
                <div className="col-md-3"></div>
            </div>
        </>   
    )
}

export default Business
