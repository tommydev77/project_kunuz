import React from 'react'
import Card from '../../components/ads/Card'
import NewBar from '../../components/latestNews/NewBar'
import MainImage from "../../assets/images/main-news.jpg"

export default function Politics() {
    return (
        <>
            <div className="container1">
				<div className="row">
					<div className="col-9">
						<Card img={MainImage} p=" On December 22-25, the delegation of Uzbekistan led by Foreign Minister Vladimir Norov will visit Tokyo to participate in the 9th Foreign Ministers’ meeting of the Central Asia + Japan dialogue." data="12:00/1.01.2022" text="Lorem ipsom dso dsadoao ko o ko koasodaoksdsad d asd asda sd aa sdf sfg gdf " />
					</div>

					<div className="col-3">
						<h4><span className="main-icon">*</span> Latest news</h4>
						<NewBar />
						<NewBar />
						<NewBar />
						<NewBar />
					</div>
				</div>
			</div>
        </>
    )
}
