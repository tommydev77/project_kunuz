import React from 'react'

export default function VerticalCard({img, data, title, width, text}) {
    return (
        <div className="card border-0" style={{width: {width}}}>
            <img src={img} className="card-img-top" alt="Card" />
            <div className="card-body p-0 pt-2">
                <p className="card-text text-secondary p-0 m-0">{data}</p>
                <h5 className="card-title p-0 m-0">{title}</h5>
                <p className="card-text text-dark p-0 m-0 pt-1">{text}</p>
            </div>
        </div>
    )
}
