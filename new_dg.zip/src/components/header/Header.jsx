import React from 'react'
import BannerImg from "../../assets/images/optimize.webp"
import {Link} from "react-router-dom"
import Logo from "../../assets/icon/logo.svg"
import "./Header.scss"

export default function Header() {
    return (
        <>
            <header className="container1">
				<img src={BannerImg} alt="BannerImage" />
			</header>
			<div className="navigations nav">
				<Link to="/"><img src={Logo} alt="Logo" /></Link>
				<Link to="/politics">Politics</Link>
				<Link to="/business">Business</Link>
				<Link to="/">Society</Link>
				<Link to="/">Tech</Link>
				<Link to="/">Culture</Link>
				<Link to="/">Sport</Link>
				<Link to="/">tourism</Link>
			</div>
        </>
    )
}
