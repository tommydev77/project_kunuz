import React from 'react'
import { Link } from 'react-router-dom';
import "./Card.scss";
function Card({img, text, data, p, link}) {
    return (
        <>
            <div className='card-ads'>
                <div className="col-6">
                    <img src={img} alt="CardImage" />
                </div>
            
                <div className="card-title col-6">
                    <div className="card-title-inside">
                        <p>
                            {data}
                        </p>
                        <h3>
                            <Link to={link}>{text}</Link>
                        </h3>

                        <p>
                            {p}
                        </p>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Card
