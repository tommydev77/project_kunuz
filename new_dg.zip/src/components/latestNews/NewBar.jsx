import React from 'react'
import "./NewBar.scss"
function NewBar() {
    return (
        <>
            <div className='NewBar'>
                <p>12:12/23.12.2022</p>
                <h5> Medical professor blamed Health Ministry for Doc-1 Max events</h5>
            </div>
        </>
    )
}

export default NewBar
