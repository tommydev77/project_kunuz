import React from 'react'
import "./MainNews.scss"
function MainNews({img,data,title}) {
    return (
        <>
            <div className='mainNews row'>
                <div className="col-4">
                    <img src={img} alt="new" />
                </div>
                <div className="col-8 bottom-line">
                    <p>{data}</p>
                    <h6>
                        {title}
                    </h6>
                </div>
            </div>
        </>
    )
}

export default MainNews
