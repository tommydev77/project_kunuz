import React from 'react'
import {Link} from "react-router-dom"
import "./Footer.scss"
function Footer() {
    return (
        <>
            <footer className='mt-5'>
                <div className="navigations">
                    <div className="col-6">
                        <div className='footerNav'>
                            <Link to="/politics">Politics</Link>
                            <Link to="/">Society</Link>
                            <Link to="/">Business</Link>
                            <Link to="/">Tech</Link>
                            <Link to="/">Culture</Link>
                            <Link to="/">Sport</Link>
                            <Link to="/">tourism</Link>
                        </div>
                    </div>

                    <div className="col-6 text-light privateAge" style={{'textAlign': "right"}}>
                        10+
                    </div>
                </div>
                <div className='footerP'>
                    <p className='text-light' style={{'width': "70%"}}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio magnam asperiores placeat eum, praesentium odit excepturi, quae dolores debitis odio animi! Est nulla obcaecati iure qui voluptatibus quas voluptates sapiente?</p>
                </div>
            </footer>
        </>
    )
}

export default Footer
