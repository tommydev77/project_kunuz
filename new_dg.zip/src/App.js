import "./assets/styles/main.scss";
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from "./pages/Home/Home";
import {Route, Routes} from "react-router-dom"
import Header from "./components/header/Header";
import Footer from "./components/footer/Footer";
import Politics from "./pages/Politics/Politics";
import Info from "./pages/Info/Info";
import InfoImage from "./assets/images/dok1.jpg"
import Business from "./pages/Business/Business";

function App() {
	return (
		<div className="App">
			<Header />
			<Routes>
				<Route path="/" element={<Home />} />
				<Route path="/politics" element={<Politics />} />
				<Route path="/info" element={<Info data="23:00/31.12.23" title="Zarifboy Ibodullayev, professor of the Tashkent Medical Academy, in an interview with Kun.uz, commented on the Doc-1 Max tragedy, accused the Ministry of Health of being indifferent to the WHO warning about the death of 69 children in Gambia." title_p="Zarifboy Ibodullayev, professor of the Tashkent Medical Academy, in an interview with Kun.uz, commented on the Doc-1 Max tragedy, accused the Ministry of Health of being indifferent to the WHO warning about the death of 69 children in Gambia." img={InfoImage} p="After the death of children caused by Doc-1 Max, the Ministry of Health issued an official response. According to it, the doctors who exposed these events were found guilty for not conducting an analysis of the children’s deaths. How do you feel about it? Is it correct to blame doctors in this process?" p2="After the death of children caused by Doc-1 Max, the Ministry of Health issued an official response. According to it, the doctors who exposed these events were found guilty for not conducting an analysis of the children’s deaths. How do you feel about it? Is it correct to blame doctors in this process?" p3="After the death of children caused by Doc-1 Max, the Ministry of Health issued an official response. According to it, the doctors who exposed these events were found guilty for not conducting an analysis of the children’s deaths. How do you feel about it? Is it correct to blame doctors in this process?" p4="After the death of children caused by Doc-1 Max, the Ministry of Health issued an official response. According to it, the doctors who exposed these events were found guilty for not conducting an analysis of the children’s deaths. How do you feel about it? Is it correct to blame doctors in this process?" p5="After the death of children caused by Doc-1 Max, the Ministry of Health issued an official response. According to it, the doctors who exposed these events were found guilty for not conducting an analysis of the children’s deaths. How do you feel about it? Is it correct to blame doctors in this process?" />} />
				<Route path="/business" element={<Business />} />
			</Routes>
			<Footer />
    	</div>
  	);
}

export default App;
